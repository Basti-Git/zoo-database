﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration; // Manuell eintragen, um Tabllen über sql anlegen zu können
using System.Data.SqlClient; // Manuell anlegen, damit die Sql Datenbank auch tatsächlich auch genutzt werden kann
using System.Data; // auch Manuell angelegt damit daten aus den Tabellen gezogen werdern können

namespace SQL_Server_einrichten
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlConnection; // diese Connection muss außerhalb der MainWindow sein, damit alle Methoden darauf zugreifen können

        public MainWindow()
        {

            InitializeComponent();
            string connectionsString = ConfigurationManager.ConnectionStrings["SQL_Server_einrichten.Properties.Settings.GabbDBConnectionString"].ConnectionString; // diese Zeile
            /* Das hier mit der DatenBank ist zimlich schwierig
             * 1. Es muss ein Verweis rechts erstellt werden, und zwar muss in der Tabelle die System.configuration ausgewählt werden
             * 2. oben muss die Biblothek System.Configuration bei using eingetragen werden
             * 3. Diese Zeile muss geschrieben werden, mit dem ProjektNamen (SQL_Server_einrichten) und wichtig den Conenection String der ein paar schritte vorher angelegt wurde. 
             * Wenn du nicht mehr weißt wie der heißt, bei Datenquellen links eine neue Datenquelle anlegen, dreimal weiter klicken, und der String wird vorausgewählt. Wenn du den aufgeschrieben hast, kannst du das neu erstellen abbrechen
            */

            sqlConnection = new SqlConnection(connectionsString); // Hier wird die Verbindung mit der Datenbank aufgenommen
            ShowZoos(); // Methode wird aufgerufen, siehe die Methode unten
            ShowAnimals();

        }

        //-------------------------------------------------------------------------------------------------------------------
        public void ShowZoos()
        {
            try // weil viel schief gehen kann in der Methode, der Code in eine try Catch Abfrage gepackt
            {
                string query = "select * from Zoo"; // das ist ein SQL Befehl und der sagt nix anderes das der komplette Inhalt der Zoo Tabelle in query gespeichert wird
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection); // der sqlDataAdapter ermöglicht es das die Tabellen wie Objekte verwendet werden können 

                using (sqlDataAdapter)
                {
                    DataTable zooTable = new DataTable();
                    sqlDataAdapter.Fill(zooTable);

                    // Welche informationen der Tabelle in unseren DataTable soll in unsere Listboch angezeigt werden
                    listZoos.DisplayMemberPath = "Location"; // die Location ist die Spalenbeschriftung in der Tabelle
                                                             // Welcher Wert soll gegeben werden, wenn eines unsere Items von der Listbox ausgewählt wird
                    listZoos.SelectedValuePath = "Id"; // auch hier ID ist der Primärschlüssel von der Tabelle
                                                       // diese Zeile bedeudet letztendlich das die Daten aus der Tabelle nun auf der listbox angezeigt werden
                    listZoos.ItemsSource = zooTable.DefaultView;

                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString()); // es wird hier einfach die Fehlermeldung (Exception) in einer Messagebox angezeigt, heißt nicht nur der Programierer sieht den Fehler, sondern auch der Nutzer

            }
        }
        //----------------------------------------------------------------------------------------------
        public void ShowAnimals()
        {
            try // weil viel schief gehen kann in der Methode, der Code in eine try Catch Abfrage gepackt
            {
                string query = "select * from Animal"; // das ist ein SQL Befehl und der sagt nix anderes das der komplette Inhalt der Animal Tabelle in query gespeichert wird
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection); // der sqlDataAdapter ermöglicht es das die Tabellen wie Objekte verwendet werden können 

                using (sqlDataAdapter)
                {
                    DataTable animalTable = new DataTable();
                    sqlDataAdapter.Fill(animalTable);

                    // Welche informationen der Tabelle in unseren DataTable soll in unsere Listboch angezeigt werden
                    listAnimal.DisplayMemberPath = "Name"; // die Location ist die Spalenbeschriftung in der Tabelle
                                                           // Welcher Wert soll gegeben werden, wenn eines unsere Items von der Listbox ausgewählt wird
                    listAnimal.SelectedValuePath = "Id"; // auch hier ID ist der Primärschlüssel von der Tabelle
                                                         // diese Zeile bedeudet letztendlich das die Daten aus der Tabelle nun auf der listbox angezeigt werden
                    listAnimal.ItemsSource = animalTable.DefaultView;

                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString()); // es wird hier einfach die Fehlermeldung (Exception) in einer Messagebox angezeigt, heißt nicht nur der Programierer sieht den Fehler, sondern auch der Nutzer

            }
        }

        //-------------------------------------------------------------------------------------------------------
        public void ShowAssociatedAnimals() // eine sehr ähnliche Methode wie ShowZoos
        {
            if (listZoos.SelectedValue == null) // Diese If Anweisung ist nötig damit die Löschen Button funktionieren, wenn zum Beispiel ein Zoo gelöscht wird, damit nicht versucht wird auf Tiere zu zugreifen die noch in einen nicht mehr vorhandenen Zoo sind
            {
                return; // Wenn also ein Zoo gelöscht wurde, mache einfach nix (return)
            }

            try // weil viel schief gehen kann in der Methode, der Code in eine try Catch Abfrage gepackt
            {
                string query = "select * from Animal a inner join ZooAnimal za on a.Id = za.AnimalId where za.ZooID = @ZooID"; // diese sehr komplizierte SQL Abfrage sagt aus das der Inhalt der Tiere aus einenm bestimmten Zoo angezeigt werden soll, der Zoo ist mit @ZooId Variable 
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection); // Dieser Aufruf ist nötig, den gibt es so nicht in der ShowZoo Methode
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand); // der sqlDataAdapter ermöglicht es das die Tabellen wie Objekte verwendet werden können 

                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue); // auch diese Zeile gibt es bei ShowZoos nicht, sie dient dazu das die Tiere aus dem angeklickten Zoo angezeigt werden 

                    DataTable animalTable = new DataTable();
                    sqlDataAdapter.Fill(animalTable);

                    // Welche informationen der Tabelle in unseren DataTable soll in unsere Listbox angezeigt werden
                    listAssociatedAnimals.DisplayMemberPath = "Name"; // der Name ist die Spaltenbeschriftung in der Tabelle
                                                                      // Welcher Wert soll gegeben werden, wenn eines unsere Items von der Listbox ausgewählt wird
                    listAssociatedAnimals.SelectedValuePath = "Id"; // auch hier ID ist der Primärschlüssel von der Tabelle
                                                                    // diese Zeile bedeudet letztendlich das die Daten aus der Tabelle nun auf der listbox angezeigt werden
                    listAssociatedAnimals.ItemsSource = animalTable.DefaultView;

                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString()); // es wird hier einfach die Fehlermeldung (Exception) in einer Messagebox angezeigt, heißt nicht nur der Programierer sieht den Fehler, sondern auch der Nutzer

            }

        }

        private void listZoos_SelectionChanged(object sender, SelectionChangedEventArgs e) // von der listBox listZoos
        {
            // (ist auskommentiert weil der Code dient nur mal um zu zeigen was der SelectedValue macht) MessageBox.Show(listZoos.SelectedValue.ToString()); // Der Wert von der SelectedValue wird in ein String umgewandelt und in einer MessageBox angezeigt
            ShowAssociatedAnimals(); // Aufruf der Methode 
            ShowSelectedZooInTextBox();

        }

        //---------------------------------------------------------------------------------------------------------

        private void DeleteZoo_Click(object sender, RoutedEventArgs e) // Methode für den Zoo Löschen Button
        {
            try
            {
                string query = "delete from Zoo where id = @ZooID"; // SQl Befehl zum Löschen des Zoos
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open(); // Verbindung der SQl Verbindung zur Datenbank
                sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue); // Anweisung die Löschen funktion von oben auszuführen wenn der Button angeklickt wird
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close(); // ganz wichtig, wenn die Datenbank mit Sql Connection geöffnet wurde, muss sie auch hier geschloßen werden
                ShowZoos(); // Damit die Anzeige in der Listbox auch aktuell ist, hier die Methode ShowZoos aufgerufen, sonst sieht der Nutzer keine Veränderung
            }



        }
        //-----------------------------------------------------------------------------------------------------------------

        // Methode um einen Zoo hinzu zufügen, für Button AddZoo
        public void AddZoo_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "insert into Zoo values (@Location)";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@Location", myTextbox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception)
            {
                MessageBox.Show("Fehler beim hinzufügen");

            }
            finally
            {
                sqlConnection.Close();
                ShowZoos();
            }


        }


        //-----------------------------------------------------------------------------------------------------------------------


        // Methode um ein Tier zu einen Zoo hizu zufügen, für Button AddTierToZoo
        private void AddAnimalToZoo_Click(object sender, RoutedEventArgs e)
        {
            if (listZoos.SelectedValue == null || listAnimal.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "insert into ZooAnimal values (@ZooID, @AnimalId)";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@AnimalId", listAnimal.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim hinzufügen eines Tieres zu einen Zoo");
            }
            finally
            {
                sqlConnection.Close();
                ShowAssociatedAnimals();
            }
        }

        //---------------------------------------------------------------------------------------------------------------------------

        // Methode um einen Tier hinzu zufügen, für Button AddTier
        public void AddAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "insert into Animal values (@Name)";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@Name", myTextbox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception)
            {
                MessageBox.Show("Fehler beim hinzufügen eines Tieres zu Tiertabelle");

            }
            finally
            {
                sqlConnection.Close();
                ShowAnimals();
            }


        }

        // ------------------------------------------------------------------------------------------------------------------------------

        // Methode um ein Tier zu Löschen, für den Button DeleteAnimal
        private void DeleteAnimal_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "delete from Animal where id = @AnimalId"; // SQl Befehl zum Löschen des Zoos
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open(); // Verbindung der SQl Verbindung zur Datenbank
                sqlCommand.Parameters.AddWithValue("@AnimalId", listAnimal.SelectedValue); // Anweisung die Löschen funktion von oben auszuführen wenn der Button angeklickt wird
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            finally
            {
                sqlConnection.Close(); // ganz wichtig, wenn die Datenbank mit Sql Connection geöffnet wurde, muss sie auch hier geschloßen werden
                ShowAnimals(); // Damit die Anzeige in der Listbox auch aktuell ist, hier die Methode ShowAnimal aufgerufen, sonst sieht der Nutzer keine Veränderung
                ShowAssociatedAnimals();
            }



        }
        //-----------------------------------------------------------------------------------------------------

        // Diese Methode wird aufgerufen sobald ein Zoo in der Zoo liste ausgewählt wird, und in der myTextbox angezeigt 
        private void ShowSelectedZooInTextBox()
        {
            if (listZoos.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "select location from Zoo where Id = @ZooID";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue);
                    DataTable zooDataTable = new DataTable();
                    sqlDataAdapter.Fill(zooDataTable);

                    myTextbox.Text = zooDataTable.Rows[0]["Location"].ToString(); // hier wird die ausgewählte Location aus der Zoo Liste in der myTextbox angezeigt  
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        //-----------------------------------------------------------------------------------------------------

        // Diese Methode wird aufgerufen sobald ein Zoo in der Zoo liste ausgewählt wird, und in der myTextbox angezeigt 
        private void ShowSelectedAnimalInTextBox()
        {
            if (listAnimal.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "select name from Animal where Id = @AnimalId";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                using (sqlDataAdapter)
                {
                    sqlCommand.Parameters.AddWithValue("@AnimalId", listAnimal.SelectedValue);
                    DataTable animalDataTable = new DataTable();
                    sqlDataAdapter.Fill(animalDataTable);

                    myTextbox.Text = animalDataTable.Rows[0]["Name"].ToString(); // hier wird die ausgewählte Location aus der Animal Liste in der myTextbox angezeigt  
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }
        // diese Methode ist nötig damit die ShowSelectedAnimalInTextBox Methode überhaupt mal aufgerufen wird, das heißt die Methode wird aufgerufen sobald listAnimal angeklickt wird
        private void listAnimal_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowSelectedAnimalInTextBox();
        }
        //-------------------------------------------------------------------------------------------------------

        // diese Methode wird ausgeführt sobald der Button updateZoo angeklickt wird, Der Button dient dazu den Namen eines Zoos zu ändern also von Berlin zu Berlina zum Beispiel, wird somit in der Tablle geändert
        private void UpdateZoo_Click(object sender, RoutedEventArgs e)
        {

            if (listZoos.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "update Zoo Set Location = @Location where Id = @ZooID";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@Location", myTextbox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Fehler beim aktualisieren eines Zoos");
            }
            finally
            {
                sqlConnection.Close();
                ShowZoos();
            }
        }

        //-------------------------------------------------------------------------------------------------------

        // diese Methode wird ausgeführt sobald der Button updateAnimal angeklickt wird, Der Button dient dazu den Namen eines Tieres zu ändern also von Bär zu Baer zum Beispiel, wird somit in der Tablle geändert
        private void UpdateAnimal_Click(object sender, RoutedEventArgs e)
        {

            if (listAnimal.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "update Animal Set Name = @Name where Id = @AnimalId";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@AnimalId", listAnimal.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@Name", myTextbox.Text);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Fehler beim aktualisieren eines Tiers");
            }
            finally
            {
                sqlConnection.Close();
                ShowAnimals();
            }
        }
        /*Leider geht der Button noch nicht
         * 
        // Methode um ein Tier aus einen Zoo zu löschen, für Button TierAusZooLöschen
        private void DeleteAnimalToZoo_Click(object sender, RoutedEventArgs e)
        {
            if (listZoos.SelectedValue == null || listAnimal.SelectedValue == null)
            {
                return;
            }
            try
            {
                string query = "delete from ZooAnimal values (@ZooID, @AnimalId)";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlConnection.Open();
                sqlCommand.Parameters.AddWithValue("@ZooID", listZoos.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@AnimalId", listAnimal.SelectedValue);
                sqlCommand.ExecuteScalar();
            }
            catch (Exception)
            {

                MessageBox.Show("Fehler beim löschen eines Tieres zu einen Zoo");
            }
            finally
            {
                sqlConnection.Close();
                ShowAssociatedAnimals();
            }
        }
        */
    
    }





}
